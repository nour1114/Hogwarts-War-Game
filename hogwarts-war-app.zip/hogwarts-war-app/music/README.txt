Optional: put your own music file here and name it theme.mp3.
If the file exists, the game plays it on loop instead of the built-in synthesized theme (it is muted during the boss fight and the victory tune).
Only use music you own or have a license for. Do not commit it to a public repo or publish it with the app.
