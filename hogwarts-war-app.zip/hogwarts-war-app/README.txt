Hogwarts War - تطبيق PWA

مهم: التطبيق لازم يتفتح من رابط (https أو localhost)، مش بالدوبل كليك على الملف، عشان التثبيت والأوفلاين يشتغلوا.

الطريقة 1 (أسهل - أونلاين):
1) ادخلي netlify.com/drop واسحبي فولدر hogwarts-war-app كله عليه، هتاخدي رابط.
   (أو ارفعيه على GitHub Pages)
2) موبايل: افتحي الرابط في Chrome (أندرويد) > القايمة > Install app / Add to Home screen.
   آيفون: Safari > Share > Add to Home Screen.
3) لاب: Chrome أو Edge > أيقونة التثبيت في شريط العنوان > Install.

الطريقة 2 (على اللاب بس، من غير نت):
   افتحي Terminal جوه الفولدر واكتبي: python -m http.server 8000
   وافتحي http://localhost:8000 ثم Install.

بعد أول فتح، اللعبة بتشتغل أوفلاين.
